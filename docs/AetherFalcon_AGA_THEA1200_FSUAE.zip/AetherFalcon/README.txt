AETHER FALCON: VANGUARD v0.2.0.5 [thea1200] (2026)
Bare-Metal Amiga 1200 AGA / THEA1200 3D Combat Sim
Controls: Joy2 / THEA1200 Pad / Arrows + Space | Exit: LMB or ESC
