AETHER FALCON: VANGUARD v0.1.3.1 [thea1200] (2026)
Bare-Metal Amiga 1200 AGA / THEA1200 3D Combat Sim
Controls: Joy2 / THEA1200 Pad / Arrows + Space | Exit: LMB or ESC
